```
SYS_close(3)                                                    = 0
```
