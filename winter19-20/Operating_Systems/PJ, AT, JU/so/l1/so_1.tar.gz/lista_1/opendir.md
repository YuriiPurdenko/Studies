opendir używa następujących wywołań systemowych

```
SYS_openat(0xffffff9c, 0x7fff3ccf8767, 0x90800, 0)              = 3
SYS_fstat(3, 0x7fff3ccf7880)                                    = 0
SYS_brk(0)                                                      = 0x5618b6cf9000
SYS_brk(0x5618b6d1a000)                                         = 0x5618b6d1a000
```
