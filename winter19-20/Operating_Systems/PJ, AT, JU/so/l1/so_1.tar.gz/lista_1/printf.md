```
SYS_write(1, "1_ls.c\n", 71_ls.c)                                     = 7
```
